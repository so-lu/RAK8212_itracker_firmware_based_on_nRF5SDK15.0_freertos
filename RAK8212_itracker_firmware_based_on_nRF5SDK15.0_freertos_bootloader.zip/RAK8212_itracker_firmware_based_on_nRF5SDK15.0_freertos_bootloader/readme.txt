1. Download nRF5_SDK_15.0.0_a53641a from noric web page.




2. Copy itracker to the folder as follow: ...\nRF5_SDK_15.0.0_a53641a\



3. Find the project file in the folder: ...\src\nRF5_SDK_15.0.0_a53641a\dfu\