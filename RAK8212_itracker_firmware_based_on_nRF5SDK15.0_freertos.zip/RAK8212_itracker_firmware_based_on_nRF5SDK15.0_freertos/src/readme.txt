1. Download nRF5_SDK_15.0.0_a53641a from noric web page.




2. Copy itracker to the folder as follow: ...\src\nRF5_SDK_15.0.0_a53641a\itracker



3. Find the project file in the folder: ...\src\nRF5_SDK_15.0.0_a53641a\itracker\ble_peripheral\itracker\pca10040\s132\arm5_no_packs