/*
  firmware data stroge from nb-iot
*/
const unsigned int firmware[1024*40] = {

};	